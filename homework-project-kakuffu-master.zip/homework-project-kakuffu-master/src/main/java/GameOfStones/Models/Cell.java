package GameOfStones.Models;

/**
 * This is an ENUM class created to represent what will be used on grid.
 */
public enum Cell {
    STONE,
    EMPTY
}

# Game Of Stones

## Consider a game board consisting of 4x4 cells, each of which contains a piece of stone. Players move in turn. In a move, a player must choose a (non empty) row or column and take away up to 4 adjacent stones from it. The winner of the game is the player who makes the last move.

### Main Menu
![Screenshot (253)](https://user-images.githubusercontent.com/68699270/168796182-d8082460-0f5a-4f53-9109-67c7d7d90427.png)

### Game Ending
![Screenshot (256)](https://user-images.githubusercontent.com/68699270/168796525-725c9d6c-be59-44c8-81c2-11baeec50e47.png)

### Scoreboard
![Screenshot (255)](https://user-images.githubusercontent.com/68699270/168796492-4f3f9fcf-7b36-4c8d-b456-2000d82b1a51.png)
